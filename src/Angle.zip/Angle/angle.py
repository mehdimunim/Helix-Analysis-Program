from numpy.linalg import norm
from normal import *
from distance import *

from length import *
from axis import *
from dssp import *
from axis2 import *

import numpy
import math
import MDAnalysis as mda

def angle(alpha_carbons):
    """
    Calculate the length of the structure

    Can serve to learn about compression and extension of a helix during MD simulation
    cf. TRAJELIX 
    """
    axis1 = principal_axis2(alpha_carbons[0])
    axis2 = principal_axis2(alpha_carbons[-1])

    dot_product = numpy.dot(axis1, axis2)
    angle = numpy.arccos(dot_product)

    return math.degrees(angle)
